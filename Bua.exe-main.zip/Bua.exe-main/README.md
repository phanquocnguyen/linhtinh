# Búa.exe
Dành cho những con người thích tự hủy
